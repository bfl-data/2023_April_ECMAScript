// // We cannot specify the type of variable we are creating
// // We can provide/reinitialize any value to any variable
// // We can use any operator with any operand type

// // var result = 10 * true;
// // console.log(result);

// // // T && T = T
// // // T && F = F

// // console.log(true && "abc");
// // console.log(false && "xyz");

// {/* <h1 class={{isSelected() && "text-primary" || "text-danger"}}></h1> */ }

// var obj;
// // var obj = { id: 1 };

// // if ((obj == null) || (obj == undefined)) {
// //     console.error("object is null or undefined");
// // } else {
// //     console.log("object is:", obj);
// // }

// if (!obj) {
//     console.error("object is null or undefined");
// } else {
//     console.log("object is:", obj);
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("abc"));
// console.log(Boolean(""));
// console.log(Boolean(null));
// console.log(Boolean(undefined));
// console.log(Boolean({}));

// -----------------------------------------

// let a = 10;
// let b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);            // Abstract Equality
// console.log(a === b);            // Strict Equality

let a = { id: 0 };
let b = { id: 0 };
let c = b;

console.log(a == b);            // Abstract Equality
console.log(a === b);            // Strict Equality

console.log(b == c);            // Abstract Equality
console.log(b === c);           // Strict Equality