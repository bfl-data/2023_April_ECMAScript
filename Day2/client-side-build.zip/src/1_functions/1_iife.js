// function hello() {
//     console.log("Hello World!");
// }

// hello();

// IIFE
// (function () {
//     console.log("Hello World!");
// })();

// (function () {
//     console.log("Hello World!");
// }());

// (() => {
//     console.log("Hello World!");
// })();

// ----------------------------------

(function (name) {
    console.log(`Hello ${name}!`);
})("Manish");

(function (name) {
    console.log(`Hello ${name}!`);
}("Abhijeet"));

((name) => {
    console.log(`Hello ${name}!`);
})("Ramakant");