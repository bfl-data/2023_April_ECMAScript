// let count = 0;

// document.getElementById("result").innerHTML = count;

// document.getElementById("plusBtn").addEventListener("click", () => {
//     count += 1;
//     document.getElementById("result").innerHTML = count;
// });

// document.getElementById("minusBtn").addEventListener("click", () => {
//     count -= 1;
//     document.getElementById("result").innerHTML = count;
// });

// ------------------------------------------------------
const counter = (function () {
    var count = 0;

    return {
        getCount: function () {
            return count;
        },
        next: function () {
            return count += 1;
        },
        prev: function () {
            return count -= 1;
        }
    };
})();

// DOM Manipulation
document.getElementById("result").innerHTML = counter.getCount();
document.getElementById("result1").innerHTML = counter.getCount();

document.getElementById("plusBtn").addEventListener("click", () => {
    document.getElementById("result").innerHTML = counter.next();
    document.getElementById("result1").innerHTML = counter.getCount();
});

document.getElementById("minusBtn").addEventListener("click", () => {
    document.getElementById("result").innerHTML = counter.prev();
    document.getElementById("result1").innerHTML = counter.getCount();

});