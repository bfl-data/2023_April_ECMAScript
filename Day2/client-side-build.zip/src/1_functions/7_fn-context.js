'use strict'

// // // In ES ‘this’ refers to the parent of the function and the object 
// // // through which the function was called
// // function test1() {
// //     console.log(this);
// // }

// // test1();

// // const test2 = function () {
// //     console.log(this);
// // }

// // test2();

// // var p1 = {
// //     id: 1,
// //     test: function () {
// //         console.log(this);
// //     }
// // };

// // p1.test();

// // window.setInterval(p1.test, 2000);

// // ---------------------------------------

// // var person = {
// //     age: 0,
// //     growOld: function () {
// //         console.log("growOld executed, under context of:", this);
// //         this.age += 1;
// //     }
// // };

// // document.getElementById("plusBtn").addEventListener("click", person.growOld.bind(person));

// // ------------------------------------
// // var p1 = {
// //     id: 1
// // }

// // function check(x, y) {
// //     console.log(x, y);
// //     console.log(this);
// // }

// // check(2, 3);
// // check.call(p1, 20, 30);
// // check.apply(p1, [21, 31]);

// // var bindedFn = check.bind(p1);
// // bindedFn(23, 33);

// // ----------------------------------------- Function Borrowing

// // var p1 = {
// //     id: 1,
// //     name: "Manish",
// //     toJson: function () {
// //         console.log(JSON.stringify(this));
// //     }
// // };

// // var p2 = {
// //     id: 2,
// //     name: "Abhijeet",
// //     toJson: function () {
// //         console.log(JSON.stringify(this));
// //     }
// // };

// // p1.toJson();
// // p2.toJson();

// const toJson = function () {
//     console.log(JSON.stringify(this));
// }

// var p1 = {
//     id: 1,
//     name: "Manish"    
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// p1.toJson = toJson.bind(p1);
// p2.toJson = toJson.bind(p2);

// p1.toJson();
// p2.toJson();

// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s 
// current surrounding scope and no further.
console.log("Context of the file is: ", this);
var self = this; 

const test = () => {
    console.log(this);
    console.log(self === this);
}

test();

// window.setInterval(test, 2000);