// Import an entire module, for side effects only, without importing anything from the file.
// This will run the module's global code, but doesn't import any values.

// import './1_functions/1_iife';
// import './1_functions/2_fn-overloading';
// import './1_functions/3_fn-as-argument';
// import './1_functions/4_using-callbacks';
// import './1_functions/5_closures';
// import './1_functions/6_assignment';
// import './1_functions/7_fn-context';
// import './1_functions/8_fn-currying';
// import './1_functions/9_hof';

// import './2_objects/1_object-creation';
// import './2_objects/2_symbol-as-keys';
// import './2_objects/3_object-type.js';
// import './2_objects/4_object-methods.js';
// import './2_objects/5_custom-type';
// import './2_objects/6_es6-class';
// import './2_objects/7_es5-properties';
// import './2_objects/8_es6-property';
// import './2_objects/9_es6-static';
// import './2_objects/10_es5-inheritance';
// import './2_objects/11_es6-inheritance';
import './2_objects/12_compare';





