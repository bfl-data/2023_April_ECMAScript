// class Queue {
//     constructor() {
//         this._dataArray = [];
//     }

//     push(data) {
//         this._dataArray.push(data);
//     }

//     pop() {
//         return this._dataArray.shift();
//     }

//     [Symbol.iterator]() {
//         let i = 0;;
//         const self = this;

//         return {
//             next: function () {
//                 let v, d = true;

//                 if (self._dataArray[i] !== undefined) {
//                     v = self._dataArray[i];
//                     d = false;
//                     i += 1;
//                 }

//                 return {
//                     value: v,
//                     done: d
//                 };
//             }
//         };
//     }
// }

// let ordersQueue = new Queue();
// ordersQueue.push("Order Id: 1");
// ordersQueue.push("Order Id: 2");
// ordersQueue.push("Order Id: 3");

// console.log(ordersQueue.pop());
// console.log(ordersQueue.pop());
// console.log(ordersQueue.pop());

// for (const order of ordersQueue) {
//     console.log(order);
// }

// console.log(Object.getOwnPropertySymbols(Array.prototype));
// console.log(Object.getOwnPropertySymbols(Map.prototype));
// console.log(Object.getOwnPropertySymbols(Queue.prototype));

// ----------------------------------------------------
class Fibonacci {
    constructor(noOfItems) {
        this._noOfItems = noOfItems;
    }

    [Symbol.iterator]() {
        let i = 0;
        const self = this;
        let a = 0, b = 1;

        return {
            next: function () {
                if (i < self._noOfItems) {
                    const [current, nextValue] = [a, a + b];
                    [a, b] = [nextValue, a];
                    i += 1;

                    return {
                        value: current,
                        done: false
                    };
                } else {
                    return {
                        done: true
                    };
                }
            }
        };
    }
}

let fibSeries = new Fibonacci(10);

let series = [...fibSeries];
console.log(series);