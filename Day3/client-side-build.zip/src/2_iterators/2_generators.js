// // Eager Executed
// function idNormal() {
//     console.log("Hello from IdNormal Function..");
// }

// // Lazy Executed
// function* idGenerator() {
//     console.log("Hello from IdGenerator Function..");
// }

// idNormal();
// idGenerator();

// ----------------------------------

// function* idGenerator() {
//     console.log("Hello from IdGenerator Function..");
// }

// var seq = idGenerator();
// // console.log(seq);
// console.log(seq.next());

// ----------------------------------

// function* idGenerator() {
//     console.log("First output");
//     yield 1;
//     console.log("Second output");
//     yield 2;
//     console.log("Third output");
//     yield 3;
//     console.log("Last Line of Generator Function");
// }

// var seq = idGenerator();
// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());

// ----------------------------------

// class Queue {
//     constructor() {
//         this._dataArray = [];
//     }

//     push(data) {
//         this._dataArray.push(data);
//     }

//     pop() {
//         return this._dataArray.shift();
//     }

//     // *[Symbol.iterator]() {
//     //     for (let i = 0; i < this._dataArray.length; i++) {
//     //         yield this._dataArray[i];
//     //     }
//     // }

//     *[Symbol.iterator]() {
//         yield* this._dataArray;
//     }
// }

// let ordersQueue = new Queue();
// ordersQueue.push("Order Id: 1");
// ordersQueue.push("Order Id: 2");
// ordersQueue.push("Order Id: 3");

// for (const order of ordersQueue) {
//     console.log(order);
// }

// -------------------------------------------

class Fibonacci {
    constructor(noOfItems) {
        this._noOfItems = noOfItems;
    }

    *[Symbol.iterator]() {
        let i = 0, a = 0, b = 1;

        while (i < this._noOfItems) {
            const [current, nextValue] = [a, a + b];
            [a, b] = [nextValue, a];
            i += 1;

            yield current;
        }
    }
}

let fibSeries = new Fibonacci(10);

let series = [...fibSeries];
console.log(series);