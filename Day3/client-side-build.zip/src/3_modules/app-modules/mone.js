export function square(x) {
    console.warn("From mone.js file");
    return x * x;
}