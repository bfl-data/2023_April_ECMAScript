import passwordGenerator from "./password-generator"

export const utilities = {
    passwordGenerator    
}