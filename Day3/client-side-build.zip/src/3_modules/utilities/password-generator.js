export default function* passwordGenerator(length) {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?";
    let password = "";
    while (password.length < length) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    yield password;
}