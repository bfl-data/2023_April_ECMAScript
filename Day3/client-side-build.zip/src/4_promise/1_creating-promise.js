function getData() {
    var promise = new Promise((resolve, reject) => {
        // Async Code
        setTimeout(function () {
            resolve("Hello BFL");
            // reject("Some Error");
        }, 5000);
    });
    return promise;
}

var promise = getData();
// console.log(promise);

// promise.then((data) => {
//     console.log(data);
// }, (eMsg) => {
//     console.error(eMsg);
// });

// promise.then((data) => {
//     console.log(data);
// }).catch((eMsg) => {
//     console.error(eMsg);
// });

promise.then((data) => {
    console.log(data);
}).catch((eMsg) => {
    console.error(eMsg);
}).finally(() => {
    console.warn("Finally will always run");
});