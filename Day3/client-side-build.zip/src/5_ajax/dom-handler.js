import postApiClient from "./post-api-client";

var ajaxDiv = document.querySelector("#ajaxDiv");
var messageDiv = document.querySelector("#messageDiv");

if (ajaxDiv.style.display === "none") {
    ajaxDiv.style.display = "block";
    messageDiv.style.display = "none";
}

var button = document.createElement("button");
button.className = "btn btn-primary";
button.innerHTML = "Get Data";

var btnArea = document.querySelector("#btnArea");
btnArea.appendChild(button);

// 1. Hard coded Data
// button.addEventListener("click", function () {
//     // alert("Button was cliecked...");

//     const data = [
//         { name: 'John', age: 30, city: 'New York' },
//         { name: 'Jane', age: 25, city: 'Chicago' },
//         { name: 'Bob', age: 40, city: 'Los Angeles' }
//     ];

//     const table = generateTable(data);
//     var tableArea = document.querySelector("#tableArea");
//     tableArea.appendChild(table);
// });

// // 2. Using Callbacks
// button.addEventListener("click", function () {
//     postApiClient.getAllPostsUsingCallbacks((data) => {
//         const table = generateTable(data);
//         var tableArea = document.querySelector("#tableArea");
//         tableArea.appendChild(table);
//     }, (eMsg) => {
//         console.error(eMsg);
//     });
// });

// // 3. Using Promise
// button.addEventListener("click", function () {
//     postApiClient.getAllPostsUsingPromise().then((data) => {
//         const table = generateTable(data);
//         var tableArea = document.querySelector("#tableArea");
//         tableArea.appendChild(table);
//     }).catch((eMsg) => {
//         console.error(eMsg);
//     });
// });

// // 4. ECMASCRIPT 2017 - Using Async Await
// button.addEventListener("click", async function () {
//     try {
//         const data = await postApiClient.getAllPostsUsingPromise();
//         const table = generateTable(data);
//         var tableArea = document.querySelector("#tableArea");
//         tableArea.appendChild(table);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// 5. ECMASCRIPT 2017 - Using Async Function
// button.addEventListener("click", async function () {
//     try {
//         const data = await postApiClient.getAllPostsAsync();
//         const table = generateTable(data);
//         var tableArea = document.querySelector("#tableArea");
//         tableArea.appendChild(table);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// 6. ECMASCRIPT 2018 - Using Async Generator Function
// button.addEventListener("click", async function () {
//     const result = postApiClient.getAllPosts();
//     try {
//         var data = await result.next();
//         const table = generateTable(data.value);
//         var tableArea = document.querySelector("#tableArea");
//         tableArea.appendChild(table);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// 7. ECMASCRIPT 2018 - Using Async Generator Function
button.addEventListener("click", async function () {
    const result = postApiClient.getPosts([1, 4, 7, 88, 99]);
    let data = [];

    // ECMASCRIPT 2018 - Async Iterators
    for await (const postData of result) {
        data = [...data, postData];
    }

    const table = generateTable(data);
    var tableArea = document.querySelector("#tableArea");
    tableArea.appendChild(table);
});

function generateTable(data) {
    const table = document.createElement('table');
    table.className = "table table-bordered";
    const headers = Object.keys(data[0]);

    // Create header row
    const headerRow = document.createElement('tr');
    headers.forEach(headerText => {
        const header = document.createElement('th');
        const textNode = document.createTextNode(headerText.toUpperCase());
        header.appendChild(textNode);
        headerRow.appendChild(header);
    });
    table.appendChild(headerRow);

    // Create table rows
    data.forEach(obj => {
        const row = document.createElement('tr');
        headers.forEach(header => {
            const cell = document.createElement('td');
            const textNode = document.createTextNode(obj[header]);
            cell.appendChild(textNode);
            row.appendChild(cell);
        });
        table.appendChild(row);
    });

    return table;
}